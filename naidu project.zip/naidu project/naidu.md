# Online music store 
My very first Node.js project, an online music store created using node, express, mongoDb, jQuery and ejs templating engine
